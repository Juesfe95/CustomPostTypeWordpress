<?php
/**
 * Plugin Name:       API REST base by Maquinando
 * Description:       Exposición de contenido a través de wp-json
 * Version:           1.0.0
 * Author:            Daniel M. Calderón
 * License:           GPL-2.0+
 * Text Domain:       hu_admin
*/


class api_admin_admin_plugin_class
{  
    public function __construct()
    {
        
        //Rest api
        add_action('rest_api_init', array($this, 'initAPI'));  

    }
    
    public function initAPI()
    {

        // Remove the default filter.
        remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );

        // Add a Custom filter.
        add_filter( 'rest_pre_serve_request', function( $value ) {
            // header( 'Access-Control-Allow-Origin: *' );
            header( 'Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE' );
            header( 'Access-Control-Allow-Credentials: true' );
            header( 'Access-Control-Allow-Headers: *' );
            return $value;
        });

        require_once(dirname(__FILE__).'/includes/rest-api/rest-api.php');
        $restAPI = new restAPIClass();
        $restAPI->register_routes();
    }

}

define('PLUGINPATH',plugin_dir_url(__FILE__ ));
/*
if(!define('PLUGINPATH'))
{
    define('PLUGINPATH',plugin_dir_url(__FILE__ ));
}
*/

// Initialize the plugin
$api_admin_admin_plugin = new api_admin_admin_plugin_class();

?>