<?php
/**
 * @OA\Info(title="API - Rest", version="1.0")
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization');


class restAPIClass{

    public $electricProducts;
    public $newProducts;
    public $trakkuProducts;
    public function __construct()
    {
       
    }

    static $headers = array(
        'headers' => array( 
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json',
                    'X-VTEX-API-AppKey' => 'vtexappkey-auteco-YNQMGN',
                    'X-VTEX-API-AppToken'=> 'FHJZXXIIDSQNCXBYACIDNQTQAJEFQLCHSLOPFRIVSPQAWZHAGQICVHFPNSZOTCSSPJVQILSJUNKYATUBCEZZCALKFZCMSTCQWXKMDQRUXZHIXHOUYYMOCTPPXKKJJFQA')
        );

    static $host = "https://auteco.vtexcommercestable.com.br";
    static $host2 = "https://www.autecomobility.com";

    //Registra las rutas delos endpoint en el wp-json
    public function register_routes()
    {
         /**
         * @OA\Get(
         *     path="/wp-json/auteco/v2/get_products/{colletionId}",
         *     summary="Retorna los productos de la colecciÃ³n",
         *     @OA\Parameter(
         *         description="Id de la colecciÃ³n de VTEX",
         *         in="path",
         *         name="product_name",
         *         required=true,
         *         @OA\Schema(
         *           type="string",
         *         )
         *     ),
         *     tags={"Trakku"},
         *     description="Retorna los productos de la colecciÃ³n",
         *     @OA\Response(response="200", description="Json con los productos"),
         *     @OA\Response(response="404", description="Ruta no encontrada"),
         *     @OA\Response(response="403", description="Acceso denegado"),
         *     deprecated=false
         * )
         */

        //define la direccion de consumo de cada endpoint
        register_rest_route('auteco/v2', 'get_products/(?P<colletionId>[0-9-]+)', [
            'methods' => 'GET',
            'callback' => array($this, 'get_products_callback'),
        ]);
        register_rest_route('auteco/v2', 'buildMenu', [
            'methods' => 'GET',
            'callback' => array($this, 'buildMenu'),
        ]);
        register_rest_route('auteco/v2', 'getMenu', [
            'methods' => 'GET',
            'callback' => array($this, 'getMenu'),
        ]);
        register_rest_route('auteco/v2', 'buildListaMotos', [
            'methods' => 'GET',
            'callback' => array($this, 'buildListaMotos'),
        ]);
        register_rest_route('auteco/v2', 'getListaMotos', [
            'methods' => 'GET',
            'callback' => array($this, 'getListaMotos'),
        ]);
        register_rest_route('auteco/v2', 'getProductPrice/(?P<productId>[0-9-]+)', [
            'methods' => 'GET',
            'callback' => array($this, 'getProductPrice'),
        ]);
        register_rest_route('auteco/v2', 'getElectricProducts/(?P<productId>[0-9-]+)', [
            'methods' => 'GET',
            'callback' => array($this, 'getElectricProducts'),
        ]);
    }
    
    //Esta funcion construye el objeto y guarda el custom post type para el menu
    function insertar_cpt($data,$title,$posType){	
        $myData = json_encode($data);	
	    $my_post = array(
        'post_title' => $title,
		'post_content' => $myData,
		'post_type' => $posType,
        'post_status' => 'publish'
		);
		$idPost = wp_insert_post($my_post);
		if($idPost != 0){
		return "OK";
		};
		return "KO";
	}

    // Esta funcion actualiza el contenido de un custom post type por el id
    function update_cpt($data,$title){	
        $myData = json_encode($data['content']);	
	    $my_post = array(
        'ID' => $data['id'],
        'post_title' => $title,
		'post_content' => $myData
		);
		$idPost = wp_update_post($my_post);
		return $idPost;
	}

    //Esta funcion trae el ultimo post registrado
	function getMenu() {
		$args = [
		'numberposts' => 1,
		'post_type' => 'post_type_menu',
		];
		$posts = get_posts($args);
		$data = [];
		$data['ID'] = $posts[0]->ID;
		$data['content'] = json_decode($posts[0]->post_content);
        if($posts){
            return $data;
        }else{
            return $posts;
        }
	}

    private function fillArrayProducts(){
        $this->newProducts = $this->getColectionProductsById(707);
        $this->electricProducts = $this->getColectionProductsById(710);
        $this->trakkuProducts = $this->getColectionProductsById(891);
    } 
    public function buildMenu(){
        $this->fillArrayProducts();
        $searchResult=array();
        $menuMotos = $this->getMenuCollections();
        $menuBicicletas = $this->buildMenuBicicletas();
        $patinetasElectricas = $this->getMenuCollectionsPatinetasElectricas();
        $motocarros = $this->buildMenuMotoCarros();
        $autosElectricos = $this->getMenuCollectionsAutosElectricos();
        $autosComerciales = $this->buildMenuAutosComerciales();
        $accesorios = $this->buildMenuAccesorios();
        array_push($searchResult,array(
            "menu-motos" => $menuMotos,
            "menu-bicicletas" => $menuBicicletas,
            "menu-patinetas" => $patinetasElectricas,
            "motocarros" => $motocarros,
            "autosElectricos" => $autosElectricos,
            "vehiculosComerciales" => $autosComerciales,
            "accesorios" => $accesorios
        ));
        $datos = [];
        $post = $this->getMenu();
        if($post){
            $datos = array(
                'id'=> $post['ID'],
                'content'=>$searchResult
            );
            return $this->update_cpt($datos,"Menu actualizado");
        }else{
            return $this->insertar_cpt($searchResult,"Menu auteco","post_type_menu");
        }
    }

    //Esta funcion trae todas las colecciones del menu de motos 
    public function getMenuCollections()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-motos";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collection,
                    "motos"=>$sku
                ));
            }
        }
        return $searchResult;
    }

    //Esta funcion trae todos los productos para cada categoria
    public function get_products_collections($request,$colection)
    {
        $host_api = self::$host."/api/catalog/pvt/collection/$request/products?page=1&pageSize=12&Active=true&Visible=true";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $products=json_decode(wp_remote_retrieve_body($response))->Data;
        $searchResult=[];
        $count = count($products);
        if($count > 0){
            foreach($products as $product)
            {
                $marcaAux = $this->getProductData($product->ProductId);
                $marca = $marcaAux["marca"];
                $productReference = $marcaAux['productReference'];
                $releaseDate = $marcaAux['releaseDate'];
                $priceAux = $this->getProductPrice($product->ProductId);
                $price = $priceAux['price'];
                $listPrice = $priceAux['listPrice'];
                $direccion = str_replace(' ', '-', $product->ProductName);
                $direccion = strtolower($direccion);
                $sku = $this->getProductSKU($product->ProductId)[0];
                $discount = 0;
                $trakku = $this->findProductByidInCollection($this->trakkuProducts,$product->ProductId);
                $electrico = $this->findProductByidInCollection($this->electricProducts,$product->ProductId);
                $nuevo = $this->findProductByidInCollection($this->newProducts,$product->ProductId);
                if($sku->listPrice > $sku->bestPrice)
                {
                    $discount = $sku->listPrice - $sku->bestPrice;
                }
                array_push($searchResult,array(
                    "ProductId"=>$product->ProductId,
                    "SkuId"=>$product->SkuId,
                    "name"=>$product->ProductName,
                    "bestPrice"=>$price,
                    "listPrice"=>$listPrice,
                    "image"=>$sku->image,
                    "redirect"=>'/'.$direccion.'/p',
                    "marca"=>$marca,
                    "productReference"=>$productReference,
                    "releaseDate" => $releaseDate,
                    "discount" => $discount,
                    "trakku" => $trakku,
                    "electrico" => $electrico,
                    "nuevo" => $nuevo,
                    "coleccion" => $colection
                ));
            }
        }
        return($searchResult);
    }
    public function get_products_callback(WP_REST_Request $request)
    {
        $colletionId=$request->get_params()['colletionId'];
        $host_api = self::$host."/api/catalog/pvt/collection/$colletionId/products?page=1&pageSize=6&Active=true&Visible=true";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $products=json_decode(wp_remote_retrieve_body($response))->Data;
        $searchResult=[];
        foreach($products as $product)
        {
            $sku=$this->getProductSKU($product->ProductId)[0];
            array_push($searchResult,array(
                "name"=>$product->ProductName,
                "bestPrice"=>$sku->bestPrice,
                "listPrice"=>$sku->listPrice,
                "image"=>$sku->image
            ));
        }
        return $searchResult;
    }
    
    private function getProductSKU($productId)
    {
        $host_api = self::$host."/api/catalog_system/pub/products/variations/$productId";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            //return new WP_Error( $response_code, $response_message );
            return $response_code;
        }
        $data=json_decode(wp_remote_retrieve_body($response));
        return $data->skus;
    }

    private function getProductData($productId)
    {
        $host_api = self::$host."/api/catalog/pvt/product/$productId";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            //return new WP_Error( $response_code, $response_message );
            return $response_code;
        }
        $data=json_decode(wp_remote_retrieve_body($response));
        return $this->getBrand($data->BrandId,$data->RefId,$data->ReleaseDate);
    }

    private function getBrand($brandId,$RefId,$releaseDate)
    {
        $host_api = self::$host."/api/catalog_system/pvt/brand/$brandId";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            //return new WP_Error( $response_code, $response_message );
            return $response_code;
        }
        $data=json_decode(wp_remote_retrieve_body($response));
        $searchResult=array(
            "marca" => $data->name,
            "productReference" => $RefId,
            "releaseDate" => $releaseDate
        );
        return $searchResult ;
    }

    //Esta funcion se encarga de obtener el precio de los productos
    public function getProductPrice($productId)
    {
        $host_api = self::$host2."/api/catalog_system/pub/products/search/?fq=productId:$productId";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            //return new WP_Error( $response_code, $response_message );
            return $response_code;
        }
        $data=json_decode(wp_remote_retrieve_body($response));
        $count = count($data);
        if($count > 0){
            if($data[0]->items[1]->sellers[0]->commertialOffer->Price != null){
                $searchResult=array(
                    "price" => $data[0]->items[1]->sellers[0]->commertialOffer->Price,
                    "listPrice" => $data[0]->items[1]->sellers[0]->commertialOffer->ListPrice
                );
            }else{
                $searchResult=array(
                    "price" => $data[0]->items[0]->sellers[0]->commertialOffer->Price,
                    "listPrice" => $data[0]->items[0]->sellers[0]->commertialOffer->ListPrice
                );
            }
        }else{
            $searchResult=array(
                "price" => 0,
                "listPrice" => 0
            );
        }
       
        return $searchResult;
    }

    /////////////MENU BICILETAS/////////////////////////////////////////////////

    //Esta funcion trae todas las colecciones del menu de bicicletas 
    public function buildMenuBicicletas(){
        $searchResult=array();
        $electricas = $this->getMenuCollectionsBicicletasElectricas();
        $deportivas = $this->getMenuCollectionsBicicletasDeportivas();
        array_push($searchResult,array(
            "electricas" => $electricas,
            "deportivas" => $deportivas,
        ));
        return $searchResult;
    }

    public function getMenuCollectionsBicicletasElectricas()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-bicicletas-electricas";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
            $sku=$this->get_products_collections($collections[0]->id,$collections[0]->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "bicicletas"=>$sku
                ));
            }
        return $searchResult;
    }

    public function getMenuCollectionsBicicletasDeportivas()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-bicicletas-deportivas";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "bicicletas"=>$sku
                ));
            }
        }
        return $searchResult;
    }

    //////////////////////Menu patinetas electricas/////////////////////////////
    //Esta funcion trae todas las colecciones del menu de patinetas electricas 
    public function getMenuCollectionsPatinetasElectricas()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-patinetas-electricas";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "patinetas"=>$sku
                ));
            }
        }
        return $searchResult;
    }

    /////////////////////////Menu Motocarros/////////////////////////////////////

    //Esta funcion trae todas las colecciones del menu de motoCarros 
    public function buildMenuMotoCarros(){
        $searchResult=array();
        $carga = $this->getMenuCollectionsMotocarroCarga();
        $pasajeros = $this->getMenuCollectionsMotocarroPasajeros();
        array_push($searchResult,array(
            "carga" => $carga,
            "pasajeros" => $pasajeros,
        ));
        return $searchResult;
    }

    public function getMenuCollectionsMotocarroCarga()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-motocarros-carga";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "motocarros"=>$sku
                ));
            }
        }
        return $searchResult;
    }

    public function getMenuCollectionsMotocarroPasajeros()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-motocarros-pasajero";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "motocarros"=>$sku
                ));
            }
        }
        return $searchResult;
    }

     //////////////////////Menu Autos Electricos/////////////////////////////
    //Esta funcion trae todas las colecciones del menu de autos electricos 
    public function getMenuCollectionsAutosElectricos()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-autos-electricos";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "autos"=>$sku
                ));
            }
        }
        return $searchResult;
    }

    ////////////////////////Menu Vehiculos Comerciales//////////////////////////////////////

    //Esta funcion trae todas las colecciones del menu de vehiculos comerciales 
    public function buildMenuAutosComerciales(){
        $searchResult=array();
        $camiones = $this->getMenuCollectionsCamiones();
        $vans = $this->getMenuCollectionsVans();
        $pickup = $this->getMenuCollectionsPickup();
        array_push($searchResult,array(
            "camiones" => $camiones,
            "vans" => $vans,
            "pickup" => $pickup
        ));
        return $searchResult;
    }

    public function getMenuCollectionsCamiones()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-vehiculos-comerciales-camiones";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
            $sku=$this->get_products_collections($collections[0]->id,$collections[0]->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "camiones"=>$sku
                ));
            }
        return $searchResult;
    }

    public function getMenuCollectionsVans()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-vehiculos-comerciales-vans";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "vans"=>$sku
                ));
            }
        }
        return $searchResult;
    }

    public function getMenuCollectionsPickup()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-vehiculos-comerciales-pickup";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "pickups"=>$sku
                ));
            }
        }
        return $searchResult;
    }

    ////////////////////////Menu Accesorios//////////////////////////////////////

    //Esta funcion trae todas las colecciones del menu de accesorios 
    public function buildMenuAccesorios(){
        $searchResult=array();
        $cascos = $this->getMenuCollectionscascos();
        $chaquetas = $this->getMenuCollectionsChaquetas();
        $guantes = $this->getMenuCollectionsGuantes();
        $impermeables = $this->getMenuCollectionsimpermeables();
        array_push($searchResult,array(
            "cascos" => $cascos,
            "chaquetas" => $chaquetas,
            "guantes" => $guantes,
            "impermeables" => $impermeables
        ));
        return $searchResult;
    }

    public function getMenuCollectionscascos()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-accesorios-cascos";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
            $sku=$this->get_products_collections($collections[0]->id,$collections[0]->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "cascos"=>$sku
                ));
            }
        return $searchResult;
    }

    public function getMenuCollectionsChaquetas()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-accesorios-chaquetas";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "chaquetas"=>$sku
                ));
            }
        }
        return $searchResult;
    }

    public function getMenuCollectionsGuantes()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-accesorios-guantes";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "guantes"=>$sku
                ));
            }
        }
        return $searchResult;
    }

    public function getMenuCollectionsimpermeables()
    {
        $host_api = self::$host."/api/catalog_system/pvt/collection/search/menu-accesorios-impermeables";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            return new WP_Error( $response_code, $response_message );
        }
        $collections=json_decode(wp_remote_retrieve_body($response))->items;
        $searchResult=array();
        foreach($collections as $collection)
        {
            $sku=$this->get_products_collections($collection->id,$collection->name);
            $count = count($sku);
            if($count > 0){
                array_push($searchResult,array(
                    "coleccion" => $collections[0],
                    "impermeables"=>$sku
                ));
            }
        }
        return $searchResult;
    }


    ////////////////////////////////////Construir listado para todas las motos de auteco/////////////////////////////////////////
    public function buildListaMotos(){
        $this->fillArrayProducts();
        $menuMotos = $this->getMenuCollections();
        $datos = [];
        $post = $this->getListaMotos();
        if($post){
            $datos = array(
                'id'=> $post['ID'],
                'content'=>$menuMotos
            );
            return $this->update_cpt($datos,"listaMotosActualizada");
        }else{
            return $this->insertar_cpt($menuMotos,"ListaMotos","custom_post_type");
        }
    }

    //Esta funcion trae el ultimo post registrado
	function getListaMotos() {
		$args = [
		'numberposts' => 1,
		'post_type' => 'custom_post_type',
		];
		$posts = get_posts($args);
		$data = [];
		$data['ID'] = $posts[0]->ID;
		$data['content'] = json_decode($posts[0]->post_content);
        if($posts){
            return $data;
        }else{
            return $posts;
        }
	}

    public function getColectionProductsById($collectionId)
    {
        $host_api = self::$host."/api/catalog/pvt/collection/$collectionId/products?page=1&pageSize=12&Active=true&Visible=true";
        $response = wp_remote_get( $host_api , self::$headers);
        $response_code = wp_remote_retrieve_response_code( $response );
        $response_message = wp_remote_retrieve_response_message( $response );
        if(is_wp_error($response) || $response_code != 200){
            //return new WP_Error( $response_code, $response_message );
            return $response_code;
        }
        $data=json_decode(wp_remote_retrieve_body($response))->Data;
        return $data;
    }

    private function findProductByidInCollection($data,$productId){
        if(array_search($productId,array_column($data,'ProductId')) !== false)
        {
            return true;
        }else{
            return false;
        }
    }
}
?>